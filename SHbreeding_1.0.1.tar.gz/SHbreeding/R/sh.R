
sh <- function(df) {

#this code is originally wrote by Dr. A. Saed-Moucheshi to calculate
#and make Smith-hazel screening method applicable in practical plant breeding

#to extract SSCP matrices from MANOVA
library(car)

#This code section is for extracting variables for the basic formula of
#MANOVA according to next section
nm <- colnames(df); nm <- as.matrix(nm); nm[2, ]<- "Block"
nm[1, ] <- "Genotype"; nm[nrow(nm), ] <- "Yield"

clnms <- t(nm)
colnames(df) <- clnms
dt <- df[, -c(1, 2)]
xx <- as.matrix(dt)

#this the main formula based on the inserted dataset
f=manova(xx~df$Genotype + df$Block)

#Following would extract SSCP matrices for further analyses
summary(f,test="Wilks") # "Pillai","Wilks","Hotelling-Lawley","Roy"
sscp <- summary(Manova(f, type=3))
SSPEr <- sscp$SSPE
sscpG <- sscp$multivariate.tests$`df$Genotype`[[1]]
sscpR <- sscp$multivariate.tests$`df$Block`[[1]]


#Obtaining the number of blocks (reppeat) and genotypes
mg <- aggregate(df, by=list(df$Genotype), FUN=mean, na.rm=TRUE)
mr <- aggregate(df, by=list(df$Block), FUN=mean, na.rm=TRUE)
BlockN = nrow(mr)
GenotypeN = nrow(mg)


#This section calculates MSCP from SSCP and DF of the factors to obtain
#genotypic variance-covariance
dfG <-GenotypeN-1
dfR <-BlockN-1
dfE <- GenotypeN*dfR
mse <- SSPEr/dfE
msg <- sscpG/dfG
msr <- sscpR/dfR
varcovG <- (msg-mse)/BlockN
diag(varcovG) <- abs(diag(varcovG))
vr <- diag(varcovG)

#Extracting standardized regression coefficient for being used as
#"a" vector for economic values (values for indirect selection)
yy <- as.data.frame(scale(xx, center = T, scale = T))
aa <- lm(Yield~ 0 + ., yy)
a1 <- as.matrix(aa$coefficients)
yield <- max(abs(a1))*2

#Grnotypic (G) and phenotypic (P) variance-covariance matrices as well as
#vector of economic values now could be provide as follow
a <- as.matrix(rbind(a1, yield))
G <- varcovG
P <- cov(xx)
##View(a); View(P);View(G)

#Finall indices for screening elite genotypes based all used variables
I <-  (solve(P)%*% G)%*% a

#calculating finals value for each genotype according to indices (I)
avg <- aggregate(df, by=list(df$Genotype), FUN=mean, na.rm=TRUE)
rw <- avg$Genotype; avg <- avg[, -c(1:3)]
rownames(avg) <- rw
#View(avg)
#View(I)
savg <- scale(avg)
final <- as.matrix(savg)%*%as.matrix(I)
fi <- final[order(final[, 1], decreasing = T),]
x <- "Sm-Ha indx for each genotype"
fi <- as.data.frame(fi); colnames(fi) <- x
View(fi)

#Writing the output in the directory that is showing in the consule
dir <- paste(choose.dir(), '\\final_indices_for_gentypes.csv', sep="")
write.csv(fi, dir)

}
