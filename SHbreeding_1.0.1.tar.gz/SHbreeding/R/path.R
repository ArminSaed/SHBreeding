
path <- function(df) {

df <- df[ , -c(1,2)]

standard_df <- as.data.frame(scale(df))

Y <- as.data.frame(standard_df[, ncol(df)])
colnames(Y) <- "Y"
X <- as.data.frame(standard_df[, -ncol(df)])
dt <- as.data.frame(cbind(Y, X))

st <- lm(dt$Y~., data = dt)
t <- as.data.frame(summary(st)$coefficients)$Estimate
B <- as.matrix(t[-1])
BB <- matrix(B, nrow(B), nrow(B))
colnames(BB) <- colnames(X)

XX <- cor(X)

PATH <- XX*BB

cor_with_y <- cor(df)[, ncol(df)][-ncol(df)]

sum_of_col <- apply(PATH, 2, sum)

o <- matrix("", 1, ncol(PATH))

Direct_Effect <- diag(PATH)

final <- rbind(PATH, o, Direct_Effect , o, sum_of_col, o, cor_with_y)
# Colmn-wsie is the indirect effects

print(final)

dir <- paste(choose.dir(), "\\final.csv", sep="")

write.csv(final, dir)

}

